"""VRC Training Insights Agent - Strands agent with Strava integration"""

import os
import json
import re
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any
import boto3
from strands import Agent, tool
from bedrock_agentcore.runtime import BedrockAgentCoreApp

# Initialize AWS clients
dynamodb = boto3.client('dynamodb', region_name='us-east-1')

# Strava API configuration
STRAVA_API_BASE = 'https://www.strava.com/api/v3'

class StravaTools:
    """Tools for fetching Strava data using stored user tokens"""

    @staticmethod
    def get_user_tokens(strava_user_id: str) -> Dict[str, str]:
        """Fetch user's Strava tokens from DynamoDB"""
        try:
            response = dynamodb.get_item(
                TableName='vrc-users',
                Key={'strava_user_id': {'S': strava_user_id}}
            )

            if 'Item' not in response:
                raise ValueError(f"User {strava_user_id} not found")

            item = response['Item']
            access_token = item['access_token']['S']
            refresh_token = item['refresh_token']['S']
            expires_at = int(item['expires_at']['N'])

            # Check if token needs refresh
            if expires_at < int(datetime.now().timestamp()) + 3600:
                access_token, refresh_token = StravaTools.refresh_token(
                    strava_user_id, refresh_token
                )

            return {
                'access_token': access_token,
                'refresh_token': refresh_token
            }
        except Exception as e:
            raise Exception(f"Error fetching user tokens: {str(e)}")

    @staticmethod
    def refresh_token(strava_user_id: str, refresh_token: str) -> tuple[str, str]:
        """Refresh Strava access token"""
        import requests

        response = requests.post(
            'https://www.strava.com/api/v3/oauth/token',
            data={
                'client_id': '181417',
                'client_secret': '74c6a5c3e63e1deed676096a23bf4f207fb77887',
                'grant_type': 'refresh_token',
                'refresh_token': refresh_token
            }
        )

        if not response.ok:
            raise Exception(f"Token refresh failed: {response.status_code}")

        token_data = response.json()
        new_access_token = token_data['access_token']
        new_refresh_token = token_data['refresh_token']
        new_expires_at = token_data['expires_at']

        # Update DynamoDB
        dynamodb.update_item(
            TableName='vrc-users',
            Key={'strava_user_id': {'S': strava_user_id}},
            UpdateExpression='SET access_token = :at, refresh_token = :rt, expires_at = :ea, updated_at = :ua',
            ExpressionAttributeValues={
                ':at': {'S': new_access_token},
                ':rt': {'S': new_refresh_token},
                ':ea': {'N': str(new_expires_at)},
                ':ua': {'S': datetime.now().isoformat()}
            }
        )

        return new_access_token, new_refresh_token

@tool
def calculate(expression: str) -> str:
    """
    Perform mathematical calculations with high precision.

    IMPORTANT: Use this tool for ALL mathematical operations including:
    - Adding/summing numbers (e.g., "2.5 + 3.7 + 4.2")
    - Subtracting numbers (e.g., "50 - 42")
    - Multiplying numbers (e.g., "6.2 * 7")
    - Dividing numbers (e.g., "100 / 7")
    - Complex expressions (e.g., "(62.4 + 43.2 + 38.1) / 3")

    Args:
        expression: Mathematical expression to evaluate (e.g., "2.5 + 3.7 + 4.2")

    Returns:
        String with the calculation result

    Examples:
        calculate("51.2 + 49.8") -> "101.0"
        calculate("(62 + 43 + 38) / 3") -> "47.666666666666664"
        calculate("51 * 1.1") -> "56.1"
    """
    try:
        # Sanitize expression - only allow numbers, operators, parentheses, and whitespace
        if not re.match(r'^[\d\s\+\-\*\/\.\(\)]+$', expression):
            return json.dumps({
                'error': 'Invalid expression. Only numbers and basic operators (+, -, *, /, parentheses) are allowed.'
            })

        # Evaluate the expression safely
        result = eval(expression, {"__builtins__": {}}, {})

        return json.dumps({
            'expression': expression,
            'result': result
        })
    except Exception as e:
        return json.dumps({
            'error': f'Calculation error: {str(e)}',
            'expression': expression
        })

@tool
def get_recent_activities(strava_user_id: str, per_page: int = 30, days_back: int = 30) -> str:
    """
    Fetch user's recent Strava activities.

    Args:
        strava_user_id: Strava user ID
        per_page: Number of activities to fetch (default 30)
        days_back: Number of days to look back (default 30)

    Returns:
        JSON string with activities data
    """
    import requests

    tokens = StravaTools.get_user_tokens(strava_user_id)
    after_timestamp = int((datetime.now() - timedelta(days=days_back)).timestamp())

    response = requests.get(
        f'{STRAVA_API_BASE}/athlete/activities',
        headers={'Authorization': f"Bearer {tokens['access_token']}"},
        params={'per_page': per_page, 'after': after_timestamp}
    )

    if not response.ok:
        return json.dumps({'error': f"Strava API error: {response.status_code}"})

    activities = response.json()

    # Transform for analysis
    transformed = []
    for activity in activities:
        transformed.append({
            'id': activity['id'],
            'name': activity['name'],
            'type': activity['type'],
            'sport_type': activity.get('sport_type'),
            'start_date': activity['start_date_local'],
            'distance_meters': activity['distance'],
            'distance_miles': round(activity['distance'] / 1609.34, 2),
            'moving_time_seconds': activity['moving_time'],
            'elapsed_time_seconds': activity['elapsed_time'],
            'total_elevation_gain_meters': activity['total_elevation_gain'],
            'average_speed_ms': activity.get('average_speed'),
            'max_speed_ms': activity.get('max_speed'),
            'average_heartrate': activity.get('average_heartrate'),
            'max_heartrate': activity.get('max_heartrate'),
            'average_watts': activity.get('average_watts'),
            'max_watts': activity.get('max_watts'),
            'suffer_score': activity.get('suffer_score'),
            'pace_min_per_mile': round((activity['moving_time'] / 60) / (activity['distance'] / 1609.34), 2) if activity['distance'] > 0 else None
        })

    return json.dumps({
        'count': len(transformed),
        'activities': transformed
    }, indent=2)


@tool
def get_athlete_stats(strava_user_id: str) -> str:
    """
    Fetch athlete's all-time, year-to-date, and recent stats.

    Args:
        strava_user_id: Strava user ID

    Returns:
        JSON string with stats data
    """
    import requests

    tokens = StravaTools.get_user_tokens(strava_user_id)

    response = requests.get(
        f'{STRAVA_API_BASE}/athletes/{strava_user_id}/stats',
        headers={'Authorization': f"Bearer {tokens['access_token']}"}
    )

    if not response.ok:
        return json.dumps({'error': f"Strava API error: {response.status_code}"})

    return json.dumps(response.json(), indent=2)


@tool
def get_activity_details(strava_user_id: str, activity_id: int) -> str:
    """
    Fetch detailed information about a specific activity.

    Args:
        strava_user_id: Strava user ID
        activity_id: Activity ID

    Returns:
        JSON string with activity details
    """
    import requests

    tokens = StravaTools.get_user_tokens(strava_user_id)

    response = requests.get(
        f'{STRAVA_API_BASE}/activities/{activity_id}',
        headers={'Authorization': f"Bearer {tokens['access_token']}"}
    )

    if not response.ok:
        return json.dumps({'error': f"Strava API error: {response.status_code}"})

    return json.dumps(response.json(), indent=2)


@tool
def get_club_members_recent_activities(strava_user_id: str, club_id: int = None, days_back: int = 7) -> str:
    """
    Fetch recent activities from club members for comparison.

    Args:
        strava_user_id: Strava user ID
        club_id: Strava club ID (optional, will fetch user's clubs if not provided)
        days_back: Number of days to look back (default 7)

    Returns:
        JSON string with club activities
    """
    import requests

    tokens = StravaTools.get_user_tokens(strava_user_id)

    # If no club_id provided, get user's first club
    if club_id is None:
        clubs_response = requests.get(
            f'{STRAVA_API_BASE}/athlete/clubs',
            headers={'Authorization': f"Bearer {tokens['access_token']}"}
        )

        if not clubs_response.ok or not clubs_response.json():
            return json.dumps({'error': 'No clubs found'})

        club_id = clubs_response.json()[0]['id']

    # Get club activities
    response = requests.get(
        f'{STRAVA_API_BASE}/clubs/{club_id}/activities',
        headers={'Authorization': f"Bearer {tokens['access_token']}"},
        params={'per_page': 50}
    )

    if not response.ok:
        return json.dumps({'error': f"Strava API error: {response.status_code}"})

    activities = response.json()
    cutoff_date = datetime.now() - timedelta(days=days_back)

    # Filter by date and transform
    recent_activities = []
    for activity in activities:
        activity_date = datetime.fromisoformat(activity['start_date_local'].replace('Z', '+00:00'))
        if activity_date >= cutoff_date:
            recent_activities.append({
                'athlete_name': f"{activity['athlete']['firstname']} {activity['athlete']['lastname']}",
                'name': activity['name'],
                'type': activity['type'],
                'distance_miles': round(activity['distance'] / 1609.34, 2),
                'moving_time_seconds': activity['moving_time'],
                'start_date': activity['start_date_local']
            })

    return json.dumps({
        'club_id': club_id,
        'count': len(recent_activities),
        'activities': recent_activities
    }, indent=2)


# Create Strands agent with tools
agent = Agent(
    name="VRC Training Insights Agent",
    model="global.anthropic.claude-sonnet-4-5-20250929-v1:0",
    system_prompt="""You are an expert running and cycling coach for the Village Run Club (VRC).

Your role is to provide personalized training insights and recommendations based on Strava data.

You have access to the following information:
- Recent activities (runs, rides, swims, etc.)
- Athlete stats (all-time, year-to-date, recent)
- Detailed activity data (pace, heart rate, power, elevation)
- Club member activities for comparison
- A calculator tool for accurate mathematical calculations

⚠️ CRITICAL: ALWAYS use the calculate() tool for ALL mathematical operations:
- When summing weekly mileage, use calculate() to add up distances
- When calculating averages, use calculate() for division
- When computing percentages or ratios, use calculate()
- NEVER perform mental math or approximate calculations
- Double-check your calculations by using the calculator tool

Examples of when to use calculate():
- "What's my weekly total?" → calculate("6.2 + 8.5 + 5.1 + 7.3 + 10.2 + 4.8 + 9.1")
- "What's my 3-week average?" → calculate("(51 + 50 + 48) / 3")
- "10% increase from 50 miles?" → calculate("50 * 1.1")

You should provide:
1. **Training Load Analysis**: Assess weekly volume, intensity, and recovery patterns
2. **Performance Trends**: Identify improvements or concerns in pace, power, heart rate
3. **Personalized Recommendations**: Suggest specific workouts, pacing strategies, recovery days
4. **Comparative Analysis**: Compare user's performance with club members when requested

Always be encouraging and supportive. Use data to back up your insights. Keep responses conversational but informative.

When analyzing training load, consider:
- Total weekly distance/duration (use calculator for accurate totals!)
- Intensity distribution (easy vs hard efforts)
- Recovery time between hard sessions
- Trends over multiple weeks (use calculator for averages!)

When giving recommendations:
- Be specific (e.g., "Try 5x800m at 7:00/mile pace")
- Explain the reasoning behind the recommendation
- Consider the athlete's current fitness and recent training
- Base volume recommendations on accurate calculations using the calculator tool

The user's strava_user_id will be provided in the context at the beginning of each conversation.""",
    tools=[
        calculate,
        get_recent_activities,
        get_athlete_stats,
        get_activity_details,
        get_club_members_recent_activities
    ]
)

# Initialize AgentCore app
app = BedrockAgentCoreApp()


@app.entrypoint
async def invoke(payload):
    """AgentCore entrypoint for handling user requests"""

    # Extract user context and prompt
    strava_user_id = payload.get('strava_user_id')
    user_message = payload.get('prompt', '')

    if not strava_user_id:
        raise ValueError('Missing strava_user_id in payload')

    # Add user context to message
    context_message = f"[User Context: strava_user_id={strava_user_id}]\n\n{user_message}"

    # Stream response from agent
    stream = agent.stream_async(context_message)

    async for event in stream:
        yield event


if __name__ == "__main__":
    app.run()
