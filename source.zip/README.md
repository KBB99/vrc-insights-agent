# VRC Training Insights Agent

AI-powered training insights agent for Village Run Club members using Strava data.

## Features

- **Training Load Analysis**: Weekly volume, intensity, recovery patterns
- **Performance Trends**: Pace, power, heart rate improvements over time
- **Personalized Recommendations**: Specific workout suggestions based on current fitness
- **Comparative Analysis**: Compare performance with VRC club members

## Architecture

- **Framework**: Strands Agents
- **Deployment**: AWS AgentCore Runtime
- **Data Source**: Strava API v3
- **User Auth**: Stored tokens in DynamoDB (vrc-users table)

## Local Testing

```bash
# Install dependencies
pip install -r requirements.txt

# Run locally
python agent.py

# Test with curl
curl -X POST http://localhost:8080/invocations \
  -H "Content-Type: application/json" \
  -d '{
    "strava_user_id": "YOUR_USER_ID",
    "prompt": "Analyze my training load for the past 2 weeks"
  }'
```

## Deployment

Using AgentCore MCP Server:

1. Open agent.py in MCP client (Cursor, Claude Code, etc.)
2. Prompt: "Transform this agent for AgentCore runtime compatibility"
3. Prompt: "Deploy this agent to AgentCore Runtime"
4. Save the agent ARN for frontend integration

## Available Tools

### get_recent_activities
Fetches user's recent Strava activities (default: 30 days, 30 activities max)

### get_athlete_stats
Fetches all-time, YTD, and recent stats for the athlete

### get_activity_details
Fetches detailed information about a specific activity

### get_club_members_recent_activities
Fetches recent activities from club members for comparison (default: 7 days)

## Agent Instructions

The agent is configured as an expert running/cycling coach with access to:
- Recent activities and detailed metrics
- Historical stats and trends
- Club member data for comparison

It provides:
- Training load analysis
- Performance trend identification
- Personalized workout recommendations
- Motivational, data-backed coaching
